#include "stdafx.h"
#include "BuildingCounter.h"


CBuildingCounter::CBuildingCounter()
{
}


CBuildingCounter::~CBuildingCounter()
{
}

#include "stdafx.h"
#include "TileRocket.h"

using namespace std;
using namespace Gdiplus;

/// How much we offset drawing the tile to the left of the center
const int OffsetLeft = 64;

/// How much we offset drawing the tile above the center
const int OffsetDown = 32;

/// the speed of rocket flying
const double SpeedY = 100.0;

CTileRocket::CTileRocket(CCity *city) : CTile(city)
{
	wstring rocket = ImagesDirectory + L"rocket.png";
	wstring brocket = ImagesDirectory + L"rocketB.png";
	wstring frocket = ImagesDirectory + L"rocketF.png";

	mRocketImage = unique_ptr<Bitmap>(Bitmap::FromFile(rocket.c_str()));
	mBImage = unique_ptr<Bitmap>(Bitmap::FromFile(brocket.c_str()));
	mFImage = unique_ptr<Bitmap>(Bitmap::FromFile(frocket.c_str()));
}


CTileRocket::~CTileRocket()
{
	mRocketImage.release();
	mBImage.release();
	mFImage.release();
}

/**  Save this item to an XML node
* \param node The node we are going to be a child of
* \returns Allocated node
*/
std::shared_ptr<xmlnode::CXmlNode> CTileRocket::XmlSave(const std::shared_ptr<xmlnode::CXmlNode> &node)
{
	auto itemNode = CTile::XmlSave(node);

	itemNode->SetAttribute(L"type", L"rocket");

	return itemNode;
}

void CTileRocket::XmlLoad(const std::shared_ptr<xmlnode::CXmlNode>& node)
{
	CTile::XmlLoad(node);
}

void CTileRocket::Load()
{
	if(mState == Empty) 
	{
		mState = Loaded;
	}
}

void CTileRocket::Launch()
{
	if (mState == Loaded)
	{
		mState = Launching;
	}
}

void CTileRocket::Draw(Gdiplus::Graphics * graphics)
{
	switch (mState)
	{
	case Empty:
	{
		DrawImage(graphics, &mBImage);
		break;
	}

	case Loaded:
	{
		DrawImage(graphics, &mBImage);
		DrawImage(graphics, &mRocketImage);
		DrawImage(graphics, &mFImage);
		break;
	}

	case Launching:
	{
		DrawImage(graphics, &mBImage);
		DrawImage(graphics, &mRocketImage);
	}

	default:
		break;
	}
}

void CTileRocket::DrawImage(Gdiplus::Graphics *graphics, std::unique_ptr<Gdiplus::Bitmap>* image)
{
	int wid = (*image)->GetWidth();
	int hit = (*image)->GetHeight();

	if ((*image) == mRocketImage && mState == Launching)
	{
		graphics->DrawImage((*image).get(),
			GetX() - OffsetLeft, mRocketY + OffsetDown - hit,
			wid, hit);
	}
	else {
		graphics->DrawImage((*image).get(),
			GetX() - OffsetLeft, GetY() + OffsetDown - hit,
			wid, hit);
	}
}

void CTileRocket::Update(double elapsed)
{
	CTile::Update(elapsed);
	if (mState != Launching)
		return;

	if (mRocketY == 0)
	{
		mRocketY = GetY();
	}
	// when the rocket is flying...
	// SpeedY is a constant pixels per second flight speed...
	mRocketY -= (int)(SpeedY * elapsed);

	if(mRocketY < 0) {
		mState = Empty;
		mRocketY = 0;
	}
}


#include "stdafx.h"
#include "RocketCounter.h"


CRocketCounter::CRocketCounter()
{
}


CRocketCounter::~CRocketCounter()
{
}

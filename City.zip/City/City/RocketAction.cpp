#include "stdafx.h"
#include "RocketAction.h"


CRocketAction::CRocketAction(Action action)
	: mAction(action)
{
}


CRocketAction::~CRocketAction()
{
}

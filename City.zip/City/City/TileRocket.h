/**
* \file TileLauncher.h
*
* \author
*
* Class that implements a Rocket launcher tile
*/

#pragma once
#include "Tile.h"
#include "TileVisitor.h"

class CTileRocket :
	public CTile
{
public:
	CTileRocket(CCity *city);
	~CTileRocket();

	/// Default constructor (disabled)
	CTileRocket() = delete;

	/// Copy constructor (disabled)
	CTileRocket(const CTileRocket &) = delete;
	virtual std::shared_ptr<xmlnode::CXmlNode> XmlSave(const std::shared_ptr<xmlnode::CXmlNode> &node) override;
	virtual void XmlLoad(const std::shared_ptr<xmlnode::CXmlNode> &node);

	/// The possible rocket pad states
	enum States {
		Empty, Loaded, Launching
	};

	/** Accept a visitor
	* \param visitor The visitor we accept */
	virtual void Accept(CTileVisitor *visitor) override
	{
		visitor->VisitRocket(this);
	}

	States GetState()
	{
		return mState;
	}

	void SetState(States state)
	{
		mState = state;
	}

	// load the rocket
	void Load();

	// launch the rocket
	void Launch();

	/**  Draw this item
	* \param graphics The graphics context to draw on */
	virtual void Draw(Gdiplus::Graphics *graphics);
	void DrawImage(Gdiplus::Graphics *graphics, std::unique_ptr<Gdiplus::Bitmap>* image);

	///  Handle updates for animation
	/// \param elapsed The time since the last update
	virtual void Update(double elapsed);

private:
	// background image
	std::unique_ptr<Gdiplus::Bitmap> mBImage;
	// foreground image
	std::unique_ptr<Gdiplus::Bitmap> mFImage;
	// rocket image
	std::unique_ptr<Gdiplus::Bitmap> mRocketImage;
	/// The current rocket pad state
	States mState = Empty;
	// The Y position of Rocket
	int mRocketY = 0;
};


#pragma once
#include "TileVisitor.h"
#include "TileRocket.h"


class CRocketAction :
	public CTileVisitor
{
public:
	enum Action {
		Load, Launch
	};

	CRocketAction(Action action);

	~CRocketAction();

	void VisitRocket(CTileRocket *rocket)
	{
		if (mAction == Load)
		{
			rocket->Load();
		}
		else if(mAction == Launch) {
			rocket->Launch();
		}
	}


private:
	/// action type
	Action mAction = Load;
};


#pragma once
#include "TileVisitor.h"
#include "TileRocket.h"

class CRocketCounter :
	public CTileVisitor
{
public:
	CRocketCounter();
	~CRocketCounter();

	int GetNumEmptyRockets() const
	{
		return mNumEmptyRockets;
	}

	int GetNumLoadedRockets() const
	{
		return mNumLoadedRockets;
	}

	int GetNumLaunchingRockets() const
	{
		return mNumLaunchingRockets;
	}

	void VisitRocket(CTileRocket *rocket)
	{
		if( rocket->GetState() == CTileRocket::Empty) 
		{
			mNumEmptyRockets++;
		}
		else if (rocket->GetState() == CTileRocket::Loaded)
		{
			mNumLoadedRockets++;
		}
		else if (rocket->GetState() == CTileRocket::Launching)
		{
			mNumLaunchingRockets++;
		}
	}

private:
	/// empty rocket counter
	int mNumEmptyRockets = 0;
	int mNumLoadedRockets = 0;
	int mNumLaunchingRockets = 0;
};

